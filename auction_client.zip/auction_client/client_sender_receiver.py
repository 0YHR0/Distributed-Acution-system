import pickle
import socket

# Create a UDP socket
import struct

# Client application IP address and port

# Multicast address and port by which client communicate to server_directory
import threading

import time

from datetime import timezone
import datetime

from models.client_auction_dto import ClientAuctionDto

MCAST_GRP = '224.1.1.3'
MCAST_PORT = 5004



# Buffer size
buffer_size = 1024

# Message sent to server_directory
message = 'Hi server_directory!'

request_counter = 0
Dict = {}


# Join Request : 'request_no,JOIN,timestamp'
# Start Request : 'request_no,START,item_name,price,timestamp'
# Bid Request : 'request_no,BID,price,timestamp'
# End Request : 'request_no,END,timestamp'
def process_user_request(request, client_socket):
    global request_counter
    global Dict
    request_number = request_counter
    # config.addToDictionary(request_number, request)
    Dict[request_number] = request
    request_counter += 1
    dt = datetime.datetime.now(timezone.utc)
    utc_time = dt.replace(tzinfo=timezone.utc)
    utc_timestamp = utc_time.timestamp()
    request = str(request_number) + ',' + request + ',' + str(utc_timestamp)
    send_request_server(request, client_socket)
    t_end = time.time() + 15
    print(Dict)
    while time.time() < t_end:
        if request_number not in Dict:
            break
    # current_dict = config.getDictionary()
    if request_number in Dict:
        print('ERROR: Request could not reach server_directory: ' + Dict[request_number])
        print('Resend the request if you still want to process the request')
    pass


def process_request_ack(ack_msg):
    global Dict
    request_number = ack_msg.split(',')[0]
    print(" \n Acknowledgement received for request number: " + request_number)
    Dict.pop(int(request_number))
    pass


def process_update(update):
    print('\n Latest status: ', update)


# Send request to server_directory
def send_request_server(request, client_socket):
    client_socket.sendto(request.encode(), (MCAST_GRP, MCAST_PORT))
    print('Sent to server_directory: ', request)
    # client_socket.close()


def mock(client_socket):
    first_thread = threading.Thread(target=client_listen_multicast, args=())
    first_thread.start()
    second_thread = threading.Thread(target=client_listen_unicast, args=(client_socket,))
    second_thread.start()


def client_listen_multicast():
    # ip address to which clients are listening for multicast from server_directory
    CLIENT_GROUP = '224.1.1.2'
    CLIENT_GROUP_PORT = 5006
    client_group_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    client_group_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    client_group_sock.bind(('', CLIENT_GROUP_PORT))
    mreq = struct.pack("4sl", socket.inet_aton(CLIENT_GROUP), socket.INADDR_ANY)
    client_group_sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
    while True:
        update, server_address = client_group_sock.recvfrom(10240)
        msg = pickle.loads(update)
        print('Received message from server in multicast: ', pickle.loads(update))
        new_update = " Auction status: {}, Auction Item: {}, Auction Price: {}, Highest Bidder: {}, " \
                     "Last update " \
                     "at: {}".format(msg.auction_status, msg.item, msg.price,
                                     msg.bidder, msg.timestamp)
        if update:
            process_update(new_update)


def client_listen_unicast(client_socket):
    while True:
        # Receive ack for request from server_directory
        data, server = client_socket.recvfrom(buffer_size)
        unicast_msg = pickle.loads(data)
        if isinstance(unicast_msg, str) and len(unicast_msg.split(',')) > 1 \
                and unicast_msg.split(',')[1] == 'REQUEST_ACK':
            print('Received ack from server for request: ', unicast_msg)
            process_request_ack(unicast_msg)
        elif isinstance(unicast_msg, ClientAuctionDto):
            new_update = " Auction status: {}, Auction Item: {}, Auction Price: {}, Highest Bidder: {}, " \
                         "Last update " \
                         "at: {}".format(unicast_msg.auction_status, unicast_msg.item, unicast_msg.price,
                                         unicast_msg.bidder, unicast_msg.timestamp)
            process_update(new_update)
        else:
            print('Received message from server in unicast: ', unicast_msg)
            process_update(unicast_msg)

