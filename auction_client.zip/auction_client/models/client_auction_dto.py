class ClientAuctionDto:
    def __init__(self, auction_status, item, price, bidder, timestamp):
        self.auction_status = auction_status
        self.item = item
        self.price = price
        self.bidder = bidder
        self.timestamp = timestamp
