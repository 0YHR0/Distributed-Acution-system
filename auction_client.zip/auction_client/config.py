Dict = {}


def initializeDict():
    global Dict
    Dict = {}


def addToDictionary(request_number, request):
    global Dict
    print(Dict)
    Dict[request_number] = request
    print(Dict)


def removeFromDictionary(request_number):
    global Dict
    print(Dict)


def getDictionary():
    global Dict
    return Dict
