# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
from multiprocessing import Process
import socket

# Press the green button in the gutter to run the script.

from client_sender_receiver import process_user_request, mock
import config

if __name__ == '__main__':
    config.initializeDict()
    print(config.getDictionary())
    MY_HOST = socket.gethostname()
    client_address = socket.gethostbyname(MY_HOST)
    print(client_address)
    client_port = 5009
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    client_socket.bind((client_address, client_port))
    mock(client_socket)
    while True:
        # Join Request : 'JOIN'
        # Start Request : 'START,item_name,price'
        # Bid Request : 'BID,price'
        # End Request : 'END'

        request = input("\n Enter your request: ")
        process_user_request(request, client_socket)

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
