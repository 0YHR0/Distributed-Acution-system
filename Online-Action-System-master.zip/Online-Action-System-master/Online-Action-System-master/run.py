# Triggering the entire project
# Do this by run.py
import struct
import threading
import uuid
from multiprocessing.context import Process
from time import sleep

from Dynamic_discovery_v2 import dynamic_discovery_old_server
from hb_receiver import hb_receiver
from hb_sender import hb_sender
from leader_server_directory.leader_server import server_up, server_up_thread
from listen_leader_election import listen_leader_election
from server_directory.server_bid_update_receiver import leader_listener
import socket
from multiprocessing import Process

server_logic_process = None


def run():
    global server_logic_process
    # from the second server just run the dynamic_discovery_new_server()
    # Then run p2
    broadcast_port = 6001
    group_address = ('224.1.1.1', 5004)
    server_list = {}
    my_uuid = uuid.uuid4()
    p2 = threading.Thread(target=dynamic_discovery_old_server, args=(broadcast_port, group_address, my_uuid))
    p2.start()
    print("dynamic_discovery up")

    # From second server
    # server_logic_process = Process(target=leader_listener())
    # server_logic_process.start()
    # A process to listen to leader election result
    p3 = threading.Thread(target=listen_leader_election, args=(my_uuid,))
    p3.start()
    print("Leader election listener up")
    # Heartbeat
    p4 = threading.Thread(target=hb_sender, args=())
    p5 = threading.Thread(target=hb_receiver, args=())
    p4.start()
    p5.start()

    if len(server_list) < 1:
        print("starting leader server..")
        isLeader = True
        server_logic_process = threading.Thread(target=server_up_thread, args=())
        server_logic_process.start()
        print("leader server up")

        # P1 is either leader or normal server


if __name__ == '__main__':
    run()
