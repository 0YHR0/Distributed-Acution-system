auctionStatus = False  # Auction Status at the server_directory
owner = None  # Client starting the auction and bidding
auction_id = None  # Auction number
item = None  # Item name to be sent at the start of the Auction
price = None  # Bidding Price
bidder = None  # Current Highest Bidder
timestamp = None  # Current Timestamp sent by the client

