isLeader = False
server_id = None
server_list = {}
