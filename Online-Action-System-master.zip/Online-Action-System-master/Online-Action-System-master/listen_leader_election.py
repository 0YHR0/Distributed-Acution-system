import struct

from leader_server_directory.leader_server import server_up
from server_directory.server_bid_update_receiver import leader_listener
import socket
from multiprocessing import Process

server_logic_process = None


def listen_leader_election(my_uuid):
    global server_logic_process
    MCAST_GRP = '224.1.1.5'
    MCAST_PORT = 6002

    multicast_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    multicast_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    multicast_sock.bind(('', MCAST_PORT))
    mreq = struct.pack("4sl", socket.inet_aton(MCAST_GRP), socket.INADDR_ANY)
    multicast_sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)

    while True:
        print("Listening for leader election...")
        leader_election_result, leader = multicast_sock.recvfrom(1024)
        result = leader_election_result.decode()
        if result == my_uuid and isLeader == False:
            isLeader = True
            server_logic_process.terminate()
            server_logic_process = Process(target=server_up())
            server_logic_process.start()
        elif result == my_uuid and isLeader == True:
            pass
        elif result != my_uuid and isLeader == True:
            isLeader = False
            server_logic_process.terminate()
            server_logic_process = Process(target=leader_listener())
            server_logic_process.start()
        else:
            pass
