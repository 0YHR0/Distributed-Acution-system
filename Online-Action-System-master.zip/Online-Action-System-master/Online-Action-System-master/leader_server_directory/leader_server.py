from audioop import add
import pickle
import socket
import struct
from multiprocessing import Process

from Dynamic_discovery_v2 import get_server_list
from leader_server_directory import leader_bid_update_sender
from leader_server_directory.auction import start_auction, end_auction, bid_auction, join_auction
from models.client_auction_dto import ClientAuctionDto


def server_up_thread():
    p1 = Process(target=server_up())
    p1.start()
    # print("leader server up....")


def server_up():
    # Bind socket to multicast address to which clients send requests
    MCAST_GRP = '224.1.1.3'
    MCAST_PORT = 5004

    multicast_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    multicast_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    multicast_sock.bind(('', MCAST_PORT))

    mreq = struct.pack("4sl", socket.inet_aton(MCAST_GRP), socket.INADDR_ANY)
    multicast_sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
    buffer_size = 1024

    while True:
        print('\nWaiting to receive request from client...\n')

        # Receive message from client
        data, address = multicast_sock.recvfrom(buffer_size)
        print(address)

        if data:
            # Process client request
            client_request = str(data.decode())
            received_request = client_request.split(',')
            print(received_request)
            # Join Request : 'request_no,JOIN,timestamp'
            # Start Request : 'request_no,START,item_name,price,timestamp'
            # Bid Request : 'request_no,BID,price,timestamp'
            # End Request : 'request_no,END,timestamp'
            if received_request[1] == 'START':
                auction_details = start_auction(address[0], received_request[2], int(received_request[3]),
                                                received_request[4])  # Owner, item name, starting Price and timestamp.
                if auction_details != 'NO':
                    # Multicast auction_details to all servers
                    leader_bid_update_sender.multicast_to_server_group(auction_details, 6790, get_server_list())
                    # Multicast auction_details to all clients
                    client_auction_details = ClientAuctionDto(auction_details.auction_status, auction_details.item,
                                                              auction_details.price,
                                                              auction_details.bidder, auction_details.timestamp)
                    leader_bid_update_sender.multicast_to_client_group(pickle.dumps(client_auction_details), 6790)
                leader_bid_update_sender.unicast_ack_to_client(pickle.dumps(received_request[0] + ',REQUEST_ACK'), address, 6790)

            if received_request[1] == 'END':
                auction_result = end_auction(address[0], received_request[2])  # Auction is ended
                if auction_result != 'NO':
                    # Multicast auction_details to all servers
                    leader_bid_update_sender.multicast_to_server_group(auction_result, 6790,get_server_list())
                    # Multicast auction_details to all clients
                    client_auction_result = ClientAuctionDto(auction_result.last_auction_details.auction_status,
                                                             auction_result.last_auction_details.item,
                                                             auction_result.last_auction_details.price,
                                                             auction_result.last_auction_details.bidder,
                                                             auction_result.last_auction_details.end_timestamp)
                    leader_bid_update_sender.multicast_to_client_group(pickle.dumps(client_auction_result), 6790)
                leader_bid_update_sender.unicast_ack_to_client(pickle.dumps(received_request[0] + ',REQUEST_ACK'), address, 6790)

            if received_request[1] == 'BID':
                auction_update = bid_auction(address[0], int(received_request[2]),
                                             received_request[3])  # Auction is updated with the bid
                if auction_update != 'NO':
                    # Multicast auction_details to all servers
                    leader_bid_update_sender.multicast_to_server_group(auction_update, 6790,get_server_list())
                    # Multicast auction_details to all clients
                    client_auction_update = ClientAuctionDto(auction_update.auction_status, auction_update.item,
                                                             auction_update.price,
                                                             auction_update.bidder, auction_update.timestamp)
                    leader_bid_update_sender.multicast_to_client_group(pickle.dumps(client_auction_update), 6790)
                leader_bid_update_sender.unicast_ack_to_client(pickle.dumps(received_request[0] + ',REQUEST_ACK'), address, 6790)

            if received_request[1] == 'JOIN':
                auction_join = join_auction()
                leader_bid_update_sender.unicast_ack_to_client(pickle.dumps(received_request[0] + ',REQUEST_ACK'), address, 6790)
                message = pickle.dumps(auction_join)
                leader_bid_update_sender.unicast_ack_to_client(message, address, 6790)
    pass
