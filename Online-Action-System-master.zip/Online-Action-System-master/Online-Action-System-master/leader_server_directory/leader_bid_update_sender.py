import pickle
import socket
import time



# ACK_GRP = [('192.168.56.1', 10001)]
bid_msg_server_id = 0


# Listening to port 5003 for acknowledgements from other servers

# server_port = 6789

# print('listening to port 5003')


def multicast_to_server_group(message, port, ACK_GRP):
    MY_HOST = socket.gethostname()
    server_address = socket.gethostbyname(MY_HOST)
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    server_socket.bind((server_address, port))
    # the ip address to which other servers are listening for multicasted auction updates
    SERVER_GROUP = '224.1.1.1'
    SERVER_GROUP_PORT = 5004

    # Sending the multicast group
    global bid_msg_server_id
    bid_msg_server_id += 1
    msg_id = bid_msg_server_id
    message_send = pickle.dumps(message)
    server_socket.sendto(message_send, (SERVER_GROUP, SERVER_GROUP_PORT))
    print('Message' + str(msg_id) + 'multicasted')

    # Checking for acknowledgements for the multicasted message
    ACK_TEMP_GRP = ACK_GRP
    t_end = time.time() + 10
    server_socket.settimeout(10)
    while len(ACK_TEMP_GRP) > 0 and time.time() < t_end:
        try:
            data, address = server_socket.recvfrom(1024)
            client_request = str(data.decode())
            received_request = client_request.split(',')
            print(received_request[0], address)
            if address in ACK_TEMP_GRP:
                ACK_TEMP_GRP.remove(address)
        except socket.timeout:
            pass

    print("Waiting for acknowledgements for multicast ends")

    if len(ACK_TEMP_GRP) < 1:
        print("All acknowledgements received")

    # Unicasting for missing acknowledgements
    else:
        print("Unicasting for missing acknowledgements begins")
        for server in ACK_TEMP_GRP:
            try:
                print('Message send to ', server)
                server_socket.sendto(message_send.encode(), server)
                t_end = time.time() + 10
                while len(ACK_TEMP_GRP) > 0 and time.time() < t_end:
                    try:
                        data, address = server_socket.recvfrom(1024)
                        if address in ACK_TEMP_GRP:
                            ACK_TEMP_GRP.remove(address)
                    except socket.timeout:
                        pass
            except Exception as e:
                print("Exception occured in sending: " + str(e))
    print("Unicasting for missing acknowledgements ends")

    # Checking if servers alive for still missing acknowledgements
    if len(ACK_TEMP_GRP) < 1:
        print("All acknowledgements received")
    else:
        print("Some servers are down")
    server_socket.close()
    pass


def multicast_to_client_group(message, port):
    MY_HOST = socket.gethostname()
    server_address = socket.gethostbyname(MY_HOST)
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    server_socket.bind((server_address, port))
    # Setting the multicast group for clients
    CLIENT_GROUP = '224.1.1.2'  # ip address to which clients are listening for multicast
    CLIENT_GROUP_PORT = 5006

    server_socket.sendto(message, (CLIENT_GROUP, CLIENT_GROUP_PORT))
    print('Message sent')
    server_socket.close()


def unicast_ack_to_client(message, address, port):
    MY_HOST = socket.gethostname()
    server_address = socket.gethostbyname(MY_HOST)
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    server_socket.bind((server_address, port))
    server_socket.sendto(message, address)
    print('Message sent')
    server_socket.close()
