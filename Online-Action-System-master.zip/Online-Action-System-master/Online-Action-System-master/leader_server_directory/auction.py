from random import random

from database import auction_flags, last_auction_flags

# This application file will be run by slave servers.
from models.auction_dto import AuctionDto
from models.client_auction_dto import ClientAuctionDto
from models.end_response_dto import EndResponseDto
from models.last_auction_dto import LastAuctionDto


def bid_auction(bidder, bid, timestamp):
    if not auction_flags.auctionStatus or auction_flags.owner != bidder:
        response = 'NO'
    else:
        if auction_flags.auctionStatus and bid > auction_flags.price:  # When Auction status is active and the sent bid is higher than the current bid.
            auction_flags.bidder = bidder
            print(bidder)
            auction_flags.price = bid
            auction_flags.timestamp = timestamp
            response = AuctionDto(auction_flags.auctionStatus, auction_flags.owner, auction_flags.auction_id,
                                  auction_flags.item, auction_flags.price, auction_flags.bidder,
                                  auction_flags.timestamp)
        else:
            response = 'NO'
    print('Response to bid request: ', response)
    return response


# Start Auction

def start_auction(owner, item, start_price, timestamp):
    if not auction_flags.auctionStatus:  # Auction is not active
        auction_flags.auctionStatus = True  # Auction is started
        auction_flags.owner = owner
        auction_flags.auction_id = random()
        auction_flags.item = item
        auction_flags.price = start_price
        auction_flags.timestamp = timestamp
        response = AuctionDto(auction_flags.auctionStatus, auction_flags.owner, auction_flags.auction_id,
                              auction_flags.item, auction_flags.price, auction_flags.bidder, auction_flags.timestamp)
        # response = str(
        #     auction_flags.auctionStatus) + "," + auction_flags.owner + "," + str(auction_flags.auction_id) + "," \
        #            + auction_flags.item + "," + auction_flags.price + "," + auction_flags.bidder + "," \
        #            + auction_flags.timestamp
    else:
        response = 'NO'
    print('Response to start request: ', response)
    return response


# End Auction

def end_auction(sender, timestamp):
    if not auction_flags.auctionStatus:
        print("no auction going on")
        response = 'NO'
    elif sender != auction_flags.owner:  # Sender is not the owner.
        response = 'NO'
    else:
        last_auction_flags.item = auction_flags.item
        last_auction_flags.price = auction_flags.price
        last_auction_flags.bidder = auction_flags.bidder
        last_auction_flags.owner = auction_flags.owner
        last_auction_flags.auction_id = auction_flags.auction_id
        last_auction_flags.end_timestamp = auction_flags.timestamp
        auction_flags.item = None
        auction_flags.auction_id = None
        auction_flags.owner = None
        auction_flags.price = None
        auction_flags.bidder = None
        auction_flags.auctionStatus = False
        auction_details = AuctionDto(auction_flags.auctionStatus, auction_flags.owner, auction_flags.auction_id,
                                     auction_flags.item, auction_flags.price, auction_flags.bidder,
                                     auction_flags.timestamp)
        last_auction_details = LastAuctionDto(last_auction_flags.owner, last_auction_flags.auction_id,
                                              last_auction_flags.item, last_auction_flags.price,
                                              last_auction_flags.bidder
                                              , last_auction_flags.end_timestamp)
        response = EndResponseDto(auction_details, last_auction_details)
    return response


def join_auction():
    return ClientAuctionDto(auction_flags.auctionStatus, auction_flags.item, auction_flags.price, auction_flags.bidder,
                            auction_flags.timestamp)
