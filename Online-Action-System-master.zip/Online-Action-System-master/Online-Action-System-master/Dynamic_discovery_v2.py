import copy
import socket
import struct
import threading
import uuid

from election import start_election
from leader_server_directory.leader_bid_update_sender import multicast_to_server_group
from multiprocessing import Process

MY_HOST = socket.gethostname()
server_addr = socket.gethostbyname(MY_HOST)
server_port = 9001
server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server_list = {}
my_uuid = ""


def remove(address):
    del server_list[address]


def get_my_uuid():
    return my_uuid


def get_server_list():
    global server_list
    return server_list


# server_list should be empty
# address: the new server's address
# my_socket should be 9001
def dynamic_discovery_new_server(my_socket, broadcast_address):
    global server_list
    global my_uuid
    server_socket.bind((server_addr, server_port))
    new_uuid = uuid.uuid4()
    my_uuid = new_uuid
    # send broadcast to request to join the server group
    msg = "From new server," + new_uuid
    my_socket.sendto(msg.encode(), broadcast_address)
    # wait for the existing servers to send its own address and uuid
    while True:
        data, address = my_socket.recvfrom(1024)
        old_server_address = str(data.decode())
        received_message = old_server_address.split(',')
        print(received_message)
        if received_message[0] == 'Confirmed':
            server_list[address] = received_message[2]
            if received_message[1] == len(server_list) + 1:
                print("discovery success!")
                server_socket.close()
                start_election()
                return True


# existing servers should always run this function
def dynamic_discovery_old_server(broadcast_port, group_address, my_uuid):
    global server_list
    p1 = threading.Thread(target=dynamic_discovery_old_server_notify_other_server, args=(broadcast_port, group_address))
    p1.start()
    p2 = threading.Thread(target=dynamic_discovery_old_server_update_group_view,
                          args=(broadcast_port, group_address, my_uuid))
    p2.start()


# Thread 1: If receives “From new server, uuid” on the broadcast address---> multicast to all the servers in
# the server group"NEWSERVER, new server address, uuid"
def dynamic_discovery_old_server_notify_other_server(broadcast_port, group_address):
    # Local host information
    MY_HOST = socket.gethostname()
    MY_IP = socket.gethostbyname(MY_HOST)

    # Create a UDP socket
    listen_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    # Set the socket to broadcast and enable reusing addresses
    listen_socket.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    listen_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    # Bind socket to address and port
    listen_socket.bind((MY_IP, broadcast_port))

    print("dynamic_discovery_old_server_notify_other_server: Listening to broadcast messages")

    while True:
        data, addr = listen_socket.recvfrom(1024)
        if data:
            msg = data.decode()
            print("Received broadcast message:", msg)
            info = msg.split(',')
            if info[0] == "From new server":
                multicast_to_server_group("NEWSERVER," + addr + "," + info[1], 6791, get_server_list())


# Thread 2: If receives "NEWSERVER, new server address, uuid" on the group address ---> compare to the new address it
# receives ---> When receives all existing servers message ---> Send its own address to the  new server + server list
# length("Confirmed, server list length") ---> Add the new server to its own group view.
def dynamic_discovery_old_server_update_group_view(broadcast_port, group_address, my_uuid):
    global server_list
    server_socket.bind((server_addr, server_port))
    copy_server_list = copy.deepcopy(server_list)
    server_address = ('', 10000)
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind(server_address)
    group = socket.inet_aton(group_address[0])
    mreq = struct.pack('4sL', group, socket.INADDR_ANY)
    sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)

    while True:
        data, address = sock.recvfrom(1024)
        print(data.decode('UTF-8'), address)
        # If receives "NEWSERVER, new server address,new server uuid" on the group address
        message = data.split(',')
        if message[0] == "NEWSERVER":
            del copy_server_list[address]
            # When receives all existing servers message
            if len(copy_server_list) < 1:
                new_server_address = message[1]
                # Send its own address to the  new server + server list length + uuid("Confirmed, server list length,
                # uuid")
                server_socket.sendto("Confirmed," + str(len(server_list)) + "," + my_uuid, new_server_address)
                # Add the new server to its own group view.
                server_list[new_server_address] = message[2]
                server_socket.close()
                break
