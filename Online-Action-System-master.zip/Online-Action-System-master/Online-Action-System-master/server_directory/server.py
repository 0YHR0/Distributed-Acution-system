from database import auction_flags, last_auction_flags
from models.auction_dto import AuctionDto


def process_update(data):
    if isinstance(data, AuctionDto):
        update_auction_flags(data)
    else:
        update_auction_flags(data.AuctionDto)
        update_last_auction_flags(data.LastAuctionDto)


def update_auction_flags(auctionDto):
    auction_flags.auctionStatus = auctionDto.auction_status
    auction_flags.item = auctionDto.item
    auction_flags.price = auctionDto.price
    auction_flags.bidder = auctionDto.bidder
    auction_flags.owner = auctionDto.owner
    auction_flags.auction_id = auctionDto.auction_id
    auction_flags.end_timestamp = auctionDto.timestamp
    pass


def update_last_auction_flags(lastAuctionDto):
    last_auction_flags.auctionStatus = lastAuctionDto.auction_status
    last_auction_flags.item = lastAuctionDto.item
    last_auction_flags.price = lastAuctionDto.price
    last_auction_flags.bidder = lastAuctionDto.bidder
    last_auction_flags.owner = lastAuctionDto.owner
    last_auction_flags.auction_id = lastAuctionDto.auction_id
    last_auction_flags.end_timestamp = lastAuctionDto.timestamp
    pass
