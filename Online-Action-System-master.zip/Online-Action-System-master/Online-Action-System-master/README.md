# Online-Action-System
Distributed System for Online Auction System

Tasks to be done:
1) checkServer_bid() and timestamp implementation.
2) Multicast to the Multicast Group of Clients.
3) Leader Election Algorithm: 
    Output should consist of Flags, Leader identity and acknowledgement message, list of all Servers and Clients
4) The application flow: When the Leader Election should happen?
5) Group management module: All servers maintains a group view by itself.
                            1. When a new server want to join in, it send the message to all the servers.
                            2. When a server receives a message of a new server want to join in, it send comfirm information to all other servers
                            3. If and only if the server receives all the confirm messages from the other server, It updates its own group view.
                            Exception: Does not receive a comfirm message from a server in a certain time-->this server fails

