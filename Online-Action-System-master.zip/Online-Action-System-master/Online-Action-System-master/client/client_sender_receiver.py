import socket

# Create a UDP socket
import struct

# Client application IP address and port
from client.client_variables import Dict

# Multicast address and port by which client communicate to server_directory
MCAST_GRP = '224.1.1.3'
MCAST_PORT = 5004

# ip address to which clients are listening for multicast from server_directory
CLIENT_GROUP = '224.1.1.2'
CLIENT_GROUP_PORT = 5006
client_group_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
client_group_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

mreq = struct.pack("4sl", socket.inet_aton(MCAST_GRP), socket.INADDR_ANY)
client_group_sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
buffer_size = 1024

# Buffer size
buffer_size = 1024

# Message sent to server_directory
message = 'Hi server_directory!'


def process_request_ack(ack_msg):
    request_number = ack_msg.split(',')[0]
    print("Acknowledgement received for request number: " + request_number)
    print(Dict)
    Dict.pop(int(request_number))
    pass


def process_update(update):
    print('Latest status: ' + update)


# Send request to server_directory
def send_request_server(request, client_socket):
    client_socket.sendto(request.encode(), (MCAST_GRP, MCAST_PORT))
    print('Sent to server_directory: ', request)
    # client_socket.close()


def client_listen_up(client_socket):
    client_group_sock.bind(('', MCAST_PORT))
    client_group_sock.settimeout(1)
    client_socket.settimeout(1)
    while True:
        try:
            update, server_address = client_group_sock.recvfrom(10240)
            print('Received message from server in multicast: ', update.decode())
            if update:
                process_update(update.decode())
        except socket.timeout:
            pass
        # Receive ack for request from server_directory
        try:
            unicast_msg, server = client_socket.recvfrom(buffer_size)
            print(unicast_msg.decode().split(',')[1])
            if unicast_msg and unicast_msg.decode().split(',')[1] == 'REQUEST_ACK':
                print('Received ack from server for request: ', unicast_msg.decode())
                process_request_ack(unicast_msg.decode())
            else:
                print('Received message from server in unicast: ', unicast_msg.decode())
                process_update(unicast_msg.decode())
        except socket.timeout:
            pass
