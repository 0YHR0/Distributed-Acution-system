import time

from datetime import timezone
import datetime

from client.client_variables import Dict
from client_sender_receiver import send_request_server

request_counter = 0


# Join Request : 'request_no,JOIN,timestamp'
# Start Request : 'request_no,START,item_name,price,timestamp'
# Bid Request : 'request_no,BID,price,timestamp'
# End Request : 'request_no,END,timestamp'
def process_user_request(request, client_socket):
    global request_counter
    request_number = request_counter
    Dict[request_number] = request
    print(Dict)
    request_counter += 1
    dt = datetime.datetime.now(timezone.utc)
    utc_time = dt.replace(tzinfo=timezone.utc)
    utc_timestamp = utc_time.timestamp()
    request = str(request_number) + ',' + request + ',' + str(utc_timestamp)
    send_request_server(request, client_socket)
    t_end = time.time() + 10
    while time.time() < t_end:
        if request_number not in Dict:
            break
    if request_number in Dict:
        print('ERROR: Request could not reach server_directory: ' + Dict[request_number])
        print('Resend the request if you still want to process the request')
    pass



