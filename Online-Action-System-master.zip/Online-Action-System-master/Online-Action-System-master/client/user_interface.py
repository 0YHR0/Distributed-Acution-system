from multiprocessing import Process
import socket

from client.client_logic import process_user_request
from client.client_sender_receiver import client_listen_up

if __name__ == '__main__':
    MY_HOST = socket.gethostname()
    client_address = socket.gethostbyname(MY_HOST)
    client_port = 5009
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    client_socket.bind((client_address, client_port))
    client_listener_process = Process(target=client_listen_up, args=(client_socket,))
    client_listener_process.start()
    while True:
        # Join Request : 'JOIN'
        # Start Request : 'START,item_name,price'
        # Bid Request : 'BID,price'
        # End Request : 'END'

        request = input("Enter your request: ")
        process_user_request(request, client_socket)
