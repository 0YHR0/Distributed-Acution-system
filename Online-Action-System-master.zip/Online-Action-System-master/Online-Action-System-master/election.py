# Leader election procedure following bully algorithm
# New Server becomes or the server who detects failure becomes the coordinator of the election
import time
import socket
import struct

from Dynamic_discovery_v2 import get_my_uuid, get_server_list


def start_election():
    uuid_cord_serv = get_my_uuid()
    server_list = get_server_list()

    # To find the uuid of your ip address in heartbeat
    # you iterate through the dictionary of server_list,
    #     MY_HOST = socket.gethostname()
    #     server_address = socket.gethostbyname(MY_HOST)
    #       key = (ip address,port), so you check if this contains your ip address

# Unicast to send the election request messages
    MY_HOST = socket.gethostname()
    server_address = socket.gethostbyname(MY_HOST)
    server_port = 10007
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    server_socket.bind((server_address, server_port))
    print((server_address, server_port))
    server_socket.settimeout(1)

    # Iterate through the server_list dictionary, compare the value of each server with uuid_cord_serv
    for values in server_list:
        # unicast election request to the server if it has a higher uuid
        if values > uuid_cord_serv:
            msg = "Election request"

    # Higher servers will send OK to the coordinator server
    if msg == "Election request":
        send_msg = "Ok"

    # When the cord_server does not receive Ok message, it becomes the leader
    if time >= 5:
        # Output: Leader Server IP to the multicast IP Address of the server
        # cord_server IP address and port number
        MCAST_GRP = '224.1.1.1'
        MCAST_PORT = 5005

        multicast_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        multicast_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        multicast_sock.bind(('', MCAST_PORT))

        mreq = struct.pack("4sl", socket.inet_aton(MCAST_GRP), socket.INADDR_ANY)
        multicast_sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
        leader_msg = "I am the leader"
        isLeader = True


