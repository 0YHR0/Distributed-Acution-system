class EndResponseDto:
    def __init__(self, auction_details, last_auction_details):
        self.auction_details = auction_details
        self.last_auction_details = last_auction_details
