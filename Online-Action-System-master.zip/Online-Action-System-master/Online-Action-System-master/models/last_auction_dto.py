class LastAuctionDto:
    def __init__(self, owner, auction_id, item, price, bidder, timestamp):
        self.auction_status = False
        self.owner = owner
        self.auction_id = auction_id
        self.item = item
        self.price = price
        self.bidder = bidder
        self.end_timestamp = timestamp
