class AuctionDto:
    def __init__(self, auction_status, owner, auction_id, item, price, bidder, timestamp):
        self.auction_status = auction_status
        self.owner = owner
        self.auction_id = auction_id
        self.item = item
        self.price = price
        self.bidder = bidder
        self.timestamp = timestamp
