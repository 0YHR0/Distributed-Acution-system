""" PyHeartBeat client: sends an UDP packet to a given server every 10 seconds.

Adjust the constant parameters as needed, or call as:
    PyHBClient.py serverip [udpport]
"""

import socket
from time import time, ctime, sleep
import sys

from Dynamic_discovery_v2 import get_server_list, get_my_uuid, remove
from election import start_election


def hb_sender():
    server_list = get_server_list()
    # SERVERIP = '127.0.0.1'  # local host, just for testing
    # HBPORT = 43278  # an arbitrary UDP port
    BEATWAIT = 5  # number of seconds between heartbeats
    #
    # if len(sys.argv) > 1:
    #     SERVERIP = sys.argv[1]
    # if len(sys.argv) > 2:
    #     HBPORT = sys.argv[2]

    hbsocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    MY_HOST = socket.gethostname()
    my_address = socket.gethostbyname(MY_HOST)
    hbsocket.bind((my_address, 5111))
    hbsocket.settimeout(5)
    # print("I am alive %s , port %d" % (SERVERIP, HBPORT))

    # print "\n*** Press Ctrl-C to terminate ***\n"
    SERVER_GROUP = '224.1.1.9'
    SERVER_GROUP_PORT = 5015
    while 1:
        server_list = get_server_list()
        uuid_list = []
        for uuid in server_list.values():
            uuid_list.append(uuid)
        hbsocket.sendto("Alive?".encode(), (SERVER_GROUP, SERVER_GROUP_PORT))
        print("uuid")
        print(uuid_list)
        try:
            while len(uuid_list) > 0:
                data, address_other = hbsocket.recvfrom(1024)
                print("receive hb from: " + str(address_other))
                data = data.decode().split(',')
                if data[0] == "ALIVE":
                    uuid_list.remove(data[1])
        except socket.timeout:
            for uuid in uuid_list:
                for address, value in get_server_list():
                    if uuid == value:
                        remove(address)
                        start_election()
                        # leader election start

        # if _ _debug_ _:
        # print "Time: %s" % ctime(time(  ))
        sleep(BEATWAIT)
