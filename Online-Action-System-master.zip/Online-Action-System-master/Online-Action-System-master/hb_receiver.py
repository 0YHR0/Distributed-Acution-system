import socket
import struct


# THE reply message: "ALIVE,UUID"
from Dynamic_discovery_v2 import get_my_uuid


def hb_receiver():
    # Binding to the multicast address to listen to auction updates from leader
    MCAST_GRP = '224.1.1.9'
    MCAST_PORT = 5015

    multicast_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    multicast_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    multicast_sock.bind(('', MCAST_PORT))

    mreq = struct.pack("4sl", socket.inet_aton(MCAST_GRP), socket.INADDR_ANY)
    multicast_sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)

    # Unicast address to send acknowledgements and receive resent updates
    MY_HOST = socket.gethostname()
    # server_address = socket.gethostbyname(MY_HOST)
    # server_port = 9999
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    # server_socket.bind((server_address, server_port))
    # print((server_address, server_port))


    while True:
        data, address = multicast_sock.recvfrom(1024)  # This will not block
        print("received message:", data.decode())
        # Add the logic to use the received data
        ack_msg = "ALIVE," + get_my_uuid()
        server_socket.sendto(ack_msg.encode(), address)


